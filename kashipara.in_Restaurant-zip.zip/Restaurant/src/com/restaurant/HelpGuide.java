package com.restaurant;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;

public class HelpGuide extends Activity {
	public void onCreate(Bundle savedInstanceState) {
        Button help;
		super.onCreate(savedInstanceState);
        
     // initialise form widget
        setContentView(R.layout.help);
        
}
}